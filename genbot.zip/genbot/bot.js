const { Client, GatewayIntentBits } = require('discord.js');
const pool = require('./database'); // Import your database pool

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});

// Daily limit settings
const dailyLimits = new Map();
const maxQueriesPerDay = 500; // Maximum queries per day
const resetTimeInMillis = 24 * 60 * 60 * 1000; // 24 hours

// Event: Bot is ready
client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

// General function to handle account generation
async function generateAccount(service, message) {
  try {
    const [rows] = await pool.query(`SELECT email, password FROM ${service} LIMIT 1`); // Get the first account of the specified service

    if (rows.length > 0) {
      const account = rows[0]; // Get the first account

      // Send account details to user
      await message.author.send(`Here is your ${service.charAt(0).toUpperCase() + service.slice(1)} account:\nEmail: ${account.email}\nPassword: ${account.password}`);
      message.reply("Account details have been sent to your DMs!");

      // Delete the account from the database
      await pool.query(`DELETE FROM ${service} WHERE email = ? AND password = ?`, [account.email, account.password]);
    } else {
      message.reply(`No accounts found for ${service.charAt(0).toUpperCase() + service.slice(1)}`);
    }
  } catch (error) {
    console.error(`Error querying the database for ${service}:`, error);
    message.reply("There was an error generating your account. Please try again later.");
  }
}

// Function to add a new account to the database
async function addAccount(service, email, password, message) {
  try {
    const [result] = await pool.query(`INSERT INTO ${service} (email, password) VALUES (?, ?)`, [email, password]);
    message.reply(`${service.charAt(0).toUpperCase() + service.slice(1)} account added successfully! Email: ${email}`);
  } catch (error) {
    console.error(`Error adding ${service} account:`, error);
    message.reply("There was an error adding the account. Please try again later.");
  }
}

// Check user permission for adding accounts
function checkUserPermission(message) {
  const roleId = 'DISCORD_ROLEID'; // Replace with your specific role ID
  const member = message.member; // Get the member object

  return member.roles.cache.has(roleId);
}

// Handle command processing
async function handleAddCommand(service, entries, message) {
  if (entries.length > 0) {
    const invalidEntries = [];

    for (const entry of entries) {
      const [email, password] = entry.split(':');
      if (email && password) {
        await addAccount(service, email, password, message); // Call the function to add the account
      } else {
        invalidEntries.push(entry);
      }
    }

    if (invalidEntries.length > 0) {
      message.reply(`Invalid entries: ${invalidEntries.join(', ')}. Usage: /add${service} <email:password> [<email:password> ...]`);
    }
  } else {
    message.reply(`Usage: /add${service} <email:password> [<email:password> ...]`);
  }
}

// Event: Message received
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const userId = message.author.id;
  const now = Date.now();

  // Check and reset user's daily limit
  if (!dailyLimits.has(userId)) {
    dailyLimits.set(userId, { count: 0, lastReset: now });
  }
  
  const userData = dailyLimits.get(userId);

  // Reset the count if 24 hours have passed
  if (now - userData.lastReset > resetTimeInMillis) {
    userData.count = 0; // Reset count
    userData.lastReset = now; // Update last reset time
  }

  // Check if user has reached the daily limit
  if (userData.count >= maxQueriesPerDay) {
    return message.reply(`You have reached your daily limit of ${maxQueriesPerDay} queries. Please try again tomorrow.`);
  }

  // Handle account generation commands
  const services = ['netflix', 'spotify', 'capcut', 'filmora', 'crunchyroll'];
  for (const service of services) {
    if (message.content === `!gen${service}`) {
      await generateAccount(service, message);
      userData.count++; // Increment query count
      return;
    }
  }

  // Handle adding accounts commands
  for (const service of services) {
    if (message.content.startsWith(`/add${service}`)) {
      if (!checkUserPermission(message)) {
        return message.reply("You do not have permission to use this command.");
      }

      const args = message.content.split(' ');
      const entries = args.slice(1); // Get all parts after the command
      await handleAddCommand(service, entries, message);
      return;
    }
  }
});

client.login('ADD_TOKEN'); // Replace with your bot's token