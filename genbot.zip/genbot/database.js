// database.js

const mysql = require('mysql2');

// Create a pool of connections to the database
const pool = mysql.createPool({
  host: 'de11.spaceify.eu', // your database host
  user: 'u5907_wpqmaZhKEY', // your database user
  password: 'QCaz@2PVxHLQ0KKtXBRl9vL^', // your database password
  database: 's5907_genbot', // your database name
  port: 3306, // specify the port separately
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Export the pool for use in other files
module.exports = pool.promise(); // Use promise-based interface
